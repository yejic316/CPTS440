// Orientation.h

#ifndef ORIENTATION_H
#define ORIENTATION_H

enum Orientation {RIGHT, UP, LEFT, DOWN};

void PrintOrientation (Orientation orientation);

#endif // ORIENTATION_H
